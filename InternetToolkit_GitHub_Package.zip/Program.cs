using System;
using System.Windows;

namespace InternetToolkitWPF
{
    public partial class App : Application { }
}